package dev.alexandre.credit.application.system.enummeration

enum class Status {
  IN_PROGRESS, APPROVED, REJECT
}
