# 195_AbstraindoFormacoesDIOUsandoOrientacaoObjetosKotlin
Abstraindo Formações da DIO Usando Orientação a Objetos com Kotlin

- CONTEÚDOS
- INFORMAÇÕES

###### DESCRIÇÃO

Crie uma solução em Koltin abstraindo o domínio das "Formações Educacionais da DIO". Nesse contexto, você será desafiado a evoluir um algoritmo que explora o conceito de Programação Orientada a Objetos (POO) no domínio em questão. Sendo assim, você deverá melhorar essa abstração e resolver os TODOs definidos no código. Booooooora!?

**Kotlin****Fundamentos**

------

###### Full-Stack

###### Básico

------

###### ESPECIALISTA

![author](https://hermes.digitalinnovation.one/users/author/photos/76b931cf-84f8-4104-96fc-3610bff07431.png)

###### Venilton FalvoJr

Tech Lead, DIO[**](https://www.linkedin.com/in/falvojr) [**](https://github.com/falvojr)

https://web.dio.me/lab/abstraindo-formacoes-da-dio-usando-orientacao-objetos-com-kotlin/learning/9e812df2-d205-46a0-a233-499cb503ea12
